# Maquettes et storyboard - Transreality Copilot (résumé)

## Écrans clés
1. Tableau de bord organisationnel
   - Vue missions / dossiers / projets
   - Widgets: activité IA, files récentes, alertes compliance

2. Interface Chat Copilot
   - Zone conversation + panneau contexte (documents liés, mémoire session)
   - Boutons actions: "Générer brief", "Simuler scénario", "Créer checklist"

3. Ingestion & Knowledge Base
   - Uploader PDF/DOCX, mapping métadonnées, assigner tags
   - Visualisation index vecteur (recherche similaire)

4. Module Agents
   - Liste d'agents paramétrables (ex: "Analyste", "Planificateur")
   - Workflow visuel: déclencheur -> action -> validation humaine

## Storyboard Pilote (10 min demo)
- Connexion officier -> upload brief mission -> demander synthèse IA -> IA propose 3 options -> générer checklist -> exporter PDF -> fin

## Notes UX
- Focus sur clarté, responsabilité humaine (IA propose, humain décide)
- Fonction undo / history pour chaque suggestion IA