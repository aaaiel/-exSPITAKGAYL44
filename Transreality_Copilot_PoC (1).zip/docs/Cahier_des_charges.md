# Cahier des charges fonctionnel & technique
**Projet :** Transreality_Copilot (PoC -> Prototype -> Premier de Série -> Commercialisation)
**Version :** 1.0
**Date :** 2025-09-18
**Auteur :** Équipe Transreality / AAAIEL

## 1. Contexte et objectifs
Fournir une plateforme copilotée par IA générative (OpenAI) pour assistance décisionnelle, synthèse documentaire,
simulation et création collaborative. Première cible : clients institutionnels (défense, santé, recherche).

## 2. Périmètre MVP
- Chat contextuel avec mémoire de session
- Ingestion PDF/DOCX et indexation vecteur
- Résumés multi-niveaux et extraction d'entités
- Templates actionnables (prompts structurés)
- Auth (SSO minimal), RBAC, logs/audit

## 3. Architecture proposée (haut-niveau)
- Frontend : React (Next.js possible), PWA
- Backend : FastAPI (Python) pour microservices
- Vector DB : Milvus / FAISS (local pour PoC)
- Search : Elasticsearch (optionnel pour PoC)
- Storage : S3-compatible (minio pour dev)
- LLM : OpenAI API (gestion clés, throttling)
- Observabilité : Prometheus / Grafana

## 4. Exigences non-fonctionnelles
- Sécurité : TLS, chiffrement AES256 au repos
- Conformité : RGPD (DPIA), préparation ISO-27001
- Scalabilité : conteneurs (K8s)
- Haut niveau de traçabilité et audit

## 5. Cas d'usage (exemples)
- Officier : préparation de mission (brief, simulation, checklist)
- Médecin : synthèse dossier patient (anonymisé pour PoC)
- Chercheur : revue littérature + extraction méthodologie

## 6. Livrables (par phase)
- Phase Démo (6–12 semaines) : demo frontend/backend, ingestion, chat
- Phase Prototype (12–26 semaines) : RBAC, agents, indexation vecteurs
- Premier de série (26–40 semaines) : sécurité, conformité, on-prem

## 7. KPIs et tests
- TTFV (time-to-first-value), DAU/MAU, taux de satisfaction requête
- Tests unitaires, e2e, charge, pentest

## 8. Annexes
- Glossaire des termes (à compléter)
- Références : CNIL (RGPD), ISO27001, docs OpenAI