# Plan de conformité RGPD - checklist (synthèse)
**Projet :** Transreality_Copilot
**Date :** 2025-09-18

## 1. Responsable de traitement & DPO
- Nommer un DPO / Resp. conformité (part-time ok)
- Définir responsable(s) de traitement

## 2. Base légale & finalités
- Spécifier finalités précises (amélioration productivité, aide décisionnelle)
- Documenter bases légales (consentement, exécution de contrat, intérêt légitime)

## 3. Minimisation & pseudonymisation
- Eviter stockage inutile d'info personnellement identifiables (PII)
- Pseudonymiser données sensibles avant ingestion

## 4. DPIA
- Réaliser une Evaluation d'Impact (DPIA) si traitement à risque élevé (santé, défense)
- Documenter mesures d'atténuation

## 5. Droits des personnes
- Mettre en place procédures pour accès, rectification, suppression, portabilité
- Interface self-service + workflow interne

## 6. Sous-traitance & contrats
- Clauses contractuelles avec fournisseurs (ex: OpenAI) : confidentialité, localisation des données, logs
- Auditabilité des sous-traitants

## 7. Conservation & suppression
- Politiques de rétention (logs, données utilisateur, prompts)
- Procédure suppression définitive

## 8. Sécurité technique
- Chiffrement transit & repos, gestion clés, IAM, RBAC
- Journalisation et alerting

## 9. Gouvernance & preuve
- Registre des activités (article 30)
- Formations internes, politiques, revue périodique

## 10. Annexes
- Templates DPIA, contrats, mentions CNIL à intégrer