#!/bin/bash
# Linux/macOS portable