#!/bin/bash
# Script universel