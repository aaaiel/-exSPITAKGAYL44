# indexer_faiss.py - PoC local vector index using faiss (if available)
# Install: pip install faiss-cpu sentence-transformers
import os
import pickle
try:
    import faiss
    from sentence_transformers import SentenceTransformer
except Exception as e:
    raise ImportError("Faiss or sentence-transformers not installed: " + str(e))

MODEL = "all-MiniLM-L6-v2"

class SimpleIndexer:
    def __init__(self, dim=384):
        self.dim = dim
        self.model = SentenceTransformer(MODEL)
        self.index = faiss.IndexFlatL2(self.dim)
        self.docs = []

    def add(self, texts):
        embs = self.model.encode(texts, convert_to_numpy=True)
        self.index.add(embs)
        self.docs.extend(texts)

    def search(self, query, k=5):
        q_emb = self.model.encode([query], convert_to_numpy=True)
        D, I = self.index.search(q_emb, k)
        results = []
        for idx in I[0]:
            if idx < len(self.docs):
                results.append(self.docs[idx])
        return results

if __name__ == '__main__':
    idx = SimpleIndexer()
    idx.add(["Ceci est un test.", "Document deux.", "Analyse mission."])
    print(idx.search("test"))