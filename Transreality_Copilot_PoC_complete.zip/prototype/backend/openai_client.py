import os
import openai

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise EnvironmentError("Please set OPENAI_API_KEY in environment")

openai.api_key = OPENAI_API_KEY

def generate_completion(prompt, model="gpt-4o-mini", max_tokens=512):
    # Simple wrapper - adjust per your OpenAI plan and available models
    resp = openai.ChatCompletion.create(
        model=model,
        messages=[{"role":"user","content": prompt}],
        max_tokens=max_tokens,
        temperature=0.2
    )
    return resp.choices[0].message.content