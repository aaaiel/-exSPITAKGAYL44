# ingest_pdf.py - simple PDF text extractor for PoC
# pip install PyPDF2
import sys
from PyPDF2 import PdfReader

def extract_text(path):
    reader = PdfReader(path)
    texts = []
    for p in reader.pages:
        texts.append(p.extract_text() or "")
    return "\n".join(texts)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python ingest_pdf.py file.pdf")
        sys.exit(1)
    txt = extract_text(sys.argv[1])
    print(txt[:1000])