from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import os
import json
from typing import List

app = FastAPI(title="Transreality Copilot - PoC Backend")

from .openai_router import router as openai_router
app.include_router(openai_router, prefix='/api')

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Simple health
@app.get("/health")
async def health():
    return {"status": "ok", "service": "transreality-poc"}

# Echo chat endpoint (demo only)
@app.post("/chat")
async def chat(messages: List[dict]):
    # messages: [{"role":"user","content":"..."}]
    # For PoC we simply echo back with a canned structure.
    if not messages:
        raise HTTPException(status_code=400, detail="No messages provided")
    last = messages[-1].get("content","")
    return {"reply": f"ÉCHO PoC: reçu '{last}'", "suggestions": ["Générer brief", "Simuler scénario"]}

# File upload (store temporarily)
UPLOAD_DIR = "/tmp/transreality_uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    path = os.path.join(UPLOAD_DIR, file.filename)
    with open(path, "wb") as f:
        content = await file.read()
        f.write(content)
    return {"filename": file.filename, "size": len(content)}

if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=8000)