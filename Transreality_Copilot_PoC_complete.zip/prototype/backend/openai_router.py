from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from .openai_client import generate_completion

router = APIRouter()

class PromptIn(BaseModel):
    prompt: str

@router.post("/openai/generate")
async def generate(payload: PromptIn):
    if not payload.prompt:
        raise HTTPException(status_code=400, detail="prompt empty")
    try:
        out = generate_completion(payload.prompt)
        return {"result": out}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))