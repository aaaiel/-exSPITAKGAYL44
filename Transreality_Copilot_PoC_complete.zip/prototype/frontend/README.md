# Frontend skeleton - React
This folder contains a minimal React app skeleton for the Transreality Copilot PoC.
It is a guidance only. To run locally:
- npm install
- npm start