import React, {useState} from "react";
import axios from "axios";

export default function App(){
  const [message, setMessage] = useState("");
  const [replies, setReplies] = useState([]);
  const send = async () => {
    try{
      const res = await axios.post("http://localhost:8000/chat", [{role:"user", content: message}]);
      setReplies(prev => [...prev, {in: message, out: res.data.reply}]);
      setMessage("");
    }catch(e){
      console.error(e);
      alert("Erreur: impossible de contacter le backend");
    }
  }
  return (
    <div style={{fontFamily:"sans-serif", padding:20}}>
      <h2>Transreality Copilot - PoC</h2>
      <div>
        <input value={message} onChange={e=>setMessage(e.target.value)} placeholder="Tapez votre message..." style={{width:"60%"}}/>
        <button onClick={send} style={{marginLeft:10}}>Envoyer</button>
      </div>
      <div style={{marginTop:20}}>
        {replies.map((r,i)=>(
          <div key={i} style={{marginBottom:10, padding:10, border:"1px solid #eee"}}>
            <div><b>Vous:</b> {r.in}</div>
            <div><b>IA:</b> {r.out}</div>
          </div>
        ))}
      </div>
    </div>
  );
}