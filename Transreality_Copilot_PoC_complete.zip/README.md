# Transreality_Copilot_PoC_all_done_Files

Package de démonstration complet pour Transreality Copilot - PoC.
Contenu:
- /docs : cahier des charges, plan conformité RGPD
- /maquettes : wireframes & storyboard
- /prototype : backend (FastAPI) + frontend (React skeleton)
- /docker : Dockerfiles & docker-compose pour dev
- /ci : pipeline GitHub Actions (exemple)

Instructions rapides:
1. Backend:
   - cd prototype/backend
   - pip install -r requirements.txt
   - uvicorn main:app --reload

2. Frontend (dev):
   - cd prototype/frontend
   - npm install
   - npm start

3. Docker:
   - docker compose -f docker/docker-compose.yml up --build

Note: ceci est un PoC. Il faut intégrer clés OpenAI, sécurité, stockage durable, vector DB pour monter en fonctionnalité.

## Outils ajoutés
- prototype/backend/openai_client.py : wrapper OpenAI (utilise OPENAI_API_KEY)
- prototype/backend/indexer_faiss.py : indexeur FAISS PoC (requires faiss + sentence-transformers)
- prototype/backend/ingest_pdf.py : extraction texte PDF (PyPDF2)
- tools/md_to_pdf.py : convertisseur md->pdf (reportlab)
- tools/generate_pitch.py : génère une présentation PPTX (python-pptx)

Note: installer dépendances supplémentaires si besoin.
