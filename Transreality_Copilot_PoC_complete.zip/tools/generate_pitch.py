# generate_pitch.py - crée une présentation PPTX simple
# pip install python-pptx
from pptx import Presentation
from pptx.util import Inches, Pt

prs = Presentation()
# Slide 1 - Title
s = prs.slides.add_slide(prs.slide_layouts[0])
s.shapes.title.text = "Transreality Copilot - Pitch"
s.placeholders[1].text = "PoC → Prototype → Premier de Série → Commercialisation"

# Slide 2 - Problem & Vision
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "Problème & Vision"
tf = s.shapes.placeholders[1].text_frame
tf.text = "Problème: Complexité des tâches décisionnelles.\nVision: copilote cognitif multimodal pour accélérer la décision."

# Slide 3 - Roadmap
s = prs.slides.add_slide(prs.slide_layouts[1])
s.shapes.title.text = "Feuille de route"
tf = s.shapes.placeholders[1].text_frame
tf.text = "Phase Démo (0-3m)\nPrototype (3-6m)\nPremier de série (6-12m)\nCommercialisation"

prs.save("docs/Transreality_Pitch.pptx")
print("Saved docs/Transreality_Pitch.pptx")