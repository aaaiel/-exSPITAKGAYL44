# md_to_pdf.py - convert simple markdown file to PDF (PoC)
# Requires reportlab: pip install reportlab
import sys
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

def md_to_pdf(md_path, pdf_path):
    with open(md_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    c = canvas.Canvas(pdf_path, pagesize=A4)
    width, height = A4
    y = height - 50
    for line in lines:
        if y < 50:
            c.showPage()
            y = height - 50
        c.drawString(40, y, line.strip()[:100])
        y -= 12
    c.save()

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python md_to_pdf.py input.md output.pdf")
    else:
        md_to_pdf(sys.argv[1], sys.argv[2])