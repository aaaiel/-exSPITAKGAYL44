
Transreality Copilot PoC Package
--------------------------------
Contents:
- openapi.yaml : OpenAPI spec for the Copilot service
- copilot_service/ : Node.js PoC service (Express) -- run with `npm install && npm start`
- react_demo/src/components/CopilotFIR.jsx : React component to embed in the Transreality demo
- PoC_Proposal_Transreality_Copilot.txt : 1-page PoC proposal

Quickstart:
1. Start the PoC service:
   cd copilot_service
   npm install
   npm start
   -> Service listens on http://localhost:3001

2. In a React demo, import the CopilotFIR component and point baseUrl to http://localhost:3001 and sessionId to a session_id created by posting to /api/v1/events/artemis.

3. Create a test event:
   curl -X POST http://localhost:3001/api/v1/events/artemis -H 'Content-Type: application/json' -d '{ "event_id":"evt-1", "summary":"Test event", "initial_confidence":0.8 }'
   -> will return session_id to use in the UI.

Notes:
- This PoC is intentionally self-contained and suitable for sandbox environments.
- For production, replace in-memory stores with persistent sovereign DB and secure mTLS/JWT auth.
