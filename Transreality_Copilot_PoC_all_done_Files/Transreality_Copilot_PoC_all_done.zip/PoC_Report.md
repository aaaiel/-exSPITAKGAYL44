
# Transreality Copilot PoC — Quick Report

**Generated:** Automated build

## Overview
This reconstructed PoC implements a sandbox Transreality Copilot service and a React demo component.
It provides endpoints for event ingestion, session retrieval, and operator actions with a simple Ethics Gate.

## Endpoints implemented
- POST /api/v1/events/artemis  -> create session (returns session_id)
- GET  /api/v1/session/:session_id -> get session state
- POST /api/v1/session/:session_id/action -> take action (investigate, request_isr, escalate, dismiss)
- GET /healthz -> health check

## How to run (local)
1. cd copilot_service
2. npm install
3. npm start
4. Open the React demo and use the CopilotFIR component pointing to http://localhost:3001

## Notes & next steps
- Replace in-memory stores with persistent sovereign DB.
- Add mTLS/JWT authentication and rate limiting.
- Replace Ethics Gate stub with formal policy engine + human review path.
- Add CI tests and docker-compose for integration testing.
