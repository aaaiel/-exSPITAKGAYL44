# Installing Athérome on Windows

1. Open Command Prompt and navigate to `electron/` folder.
2. Run `build_win.bat` to generate `setup.exe` in `dist/`.
3. Double-click `setup.exe` to install Athérome.
4. Once installed, launch the app from Start Menu or Desktop shortcut.
5. Auto-update will check GitHub Releases for new versions automatically.
