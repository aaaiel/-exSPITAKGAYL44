window.electronAPI.onUpdateAvailable(() => {
  alert("Update available. Downloading...");
});

window.electronAPI.onUpdateDownloaded(() => {
  if (confirm("Update downloaded. Restart now?")) {
    // Quit and install is triggered in main.js
  }
});
