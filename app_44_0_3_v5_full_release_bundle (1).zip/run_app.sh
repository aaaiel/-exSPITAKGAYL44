#!/bin/bash
echo 'Running app 44.0.3-v5...'
