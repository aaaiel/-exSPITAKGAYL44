#!/bin/bash
echo 'Installing app 44.0.3-v5...'
